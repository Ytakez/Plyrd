package com.ytakez.youplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ytakez.youplayer.data.ListeningStats
import com.ytakez.youplayer.data.Track
import com.ytakez.youplayer.ui.components.TrackRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    tracks: List<Track>,
    recent: List<Track>,
    stats: Map<String, ListeningStats>,
    currentTrackId: String?,
    hasPermission: Boolean,
    isScanning: Boolean,
    onPlayMix: () -> Unit,
    onPlayTrack: (Track) -> Unit,
    onOpenLibrary: () -> Unit,
    onRequestPermission: () -> Unit,
) {
    Scaffold(topBar = {
        TopAppBar(title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.onPrimary) }
                Spacer(Modifier.size(12.dp))
                Text("YouPlayer", fontWeight = FontWeight.ExtraBold)
            }
        })
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding)) {
            item { MixHero(trackCount = tracks.size, onPlayMix = onPlayMix) }
            if (tracks.isEmpty()) {
                item { EmptyLibrary(hasPermission = hasPermission, isScanning = isScanning, onRequestPermission = onRequestPermission) }
            } else {
                item {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 8.dp)) {
                        StatBubble(
                            Icons.Rounded.MusicNote, "${tracks.size}", if (tracks.size == 1) "трек" else "треков",
                            RoundedCornerShape(topStart = 36.dp, topEnd = 12.dp, bottomEnd = 36.dp, bottomStart = 12.dp),
                            Modifier.weight(1f),
                        )
                        Spacer(Modifier.size(10.dp))
                        StatBubble(
                            Icons.Rounded.Favorite, "${stats.values.count { it.liked }}", "любимых",
                            RoundedCornerShape(topStart = 12.dp, topEnd = 36.dp, bottomEnd = 12.dp, bottomStart = 36.dp),
                            Modifier.weight(1f),
                        )
                    }
                }
                if (recent.isNotEmpty()) {
                    item { SectionTitle("Недавно играло") }
                    items(recent.take(5), key = { "recent_${it.id}" }) { track ->
                        TrackRow(track, { onPlayTrack(track) }, isPlaying = track.id == currentTrackId, liked = stats[track.id]?.liked == true)
                    }
                }
                item { SectionTitle("Из твоей коллекции") }
                items(tracks.filterNot { recent.any { recentTrack -> recentTrack.id == it.id } }.take(5), key = { "home_${it.id}" }) { track ->
                    TrackRow(track, { onPlayTrack(track) }, isPlaying = track.id == currentTrackId, liked = stats[track.id]?.liked == true)
                }
                item {
                    FilledTonalButton(
                        onClick = onOpenLibrary,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp).fillMaxWidth().height(56.dp),
                    ) { Text("Показать все треки") }
                    Spacer(Modifier.height(120.dp))
                }
            }
        }
    }
}

@Composable
fun MixHero(trackCount: Int, onPlayMix: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
        shape = RoundedCornerShape(44.dp),
    ) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(primary, tertiary)))) {
            Column(Modifier.padding(28.dp)) {
                Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(22.dp))
                Text("Мой умный микс", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text(
                    if (trackCount > 0) "Похожие треки по твоим вкусам. Очередь пополняется сама."
                    else "Когда музыка найдётся, микс настроится под тебя.",
                    color = Color.White.copy(alpha = 0.88f), modifier = Modifier.padding(top = 6.dp),
                )
                Button(
                    onClick = onPlayMix, enabled = trackCount > 0,
                    modifier = Modifier.padding(top = 22.dp).height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = primary),
                ) {
                    Icon(Icons.Rounded.PlayArrow, null)
                    Spacer(Modifier.size(8.dp))
                    Text("Запустить микс", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

/** Пустая библиотека: просим доступ к музыке или сообщаем, что идёт поиск. */
@Composable
fun EmptyLibrary(hasPermission: Boolean, isScanning: Boolean, onRequestPermission: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(40.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            when {
                !hasPermission -> {
                    Icon(Icons.Rounded.LibraryMusic, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Нужен доступ к музыке", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 14.dp))
                    Text(
                        "Разреши доступ к аудиофайлам — YouPlayer сам найдёт все песни на телефоне и никуда их не отправит.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 10.dp),
                    )
                    Button(onClick = onRequestPermission, Modifier.height(56.dp)) { Text("Разрешить доступ") }
                }
                isScanning -> {
                    CircularProgressIndicator(Modifier.size(40.dp))
                    Text("Ищем музыку на устройстве…", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 16.dp))
                }
                else -> {
                    Icon(Icons.Rounded.MusicNote, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                    Text("Музыка не найдена", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 14.dp))
                    Text(
                        "Положи аудиофайлы в память телефона — они появятся здесь сами.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun StatBubble(
    icon: ImageVector, value: String, label: String,
    shape: RoundedCornerShape, modifier: Modifier,
) {
    Card(
        modifier, shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
            Spacer(Modifier.size(12.dp))
            Column {
                Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSecondaryContainer)
                Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(start = 24.dp, top = 20.dp, bottom = 8.dp, end = 24.dp))
}
