package com.ytakez.youplayer.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconToggleButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

/**
 * Главная кнопка плеера в стиле Material 3 Expressive.
 * На паузе она круглая, при воспроизведении превращается в скруглённый квадрат,
 * а при нажатии на мгновение «сжимается».
 */
@Composable
fun ExpressivePlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    width: Dp = 120.dp,
    height: Dp = 88.dp,
    iconSize: Dp = 42.dp,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val corner by animateIntAsState(
        targetValue = when {
            pressed -> 20
            isPlaying -> 32
            else -> 50
        },
        label = "playCorner",
    )
    FilledIconButton(
        onClick = onClick,
        modifier = modifier.size(width = width, height = height),
        shape = RoundedCornerShape(percent = corner),
        interactionSource = interaction,
    ) {
        Icon(
            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            contentDescription = if (isPlaying) "Пауза" else "Играть",
            modifier = Modifier.size(iconSize),
        )
    }
}

/** Переключатель: выключен — круг, включён — скруглённый квадрат другого цвета. */
@Composable
fun ExpressiveToggleButton(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
) {
    val corner by animateDpAsState(if (checked) 18.dp else size / 2, label = "toggleCorner")
    FilledTonalIconToggleButton(
        checked = checked,
        onCheckedChange = onCheckedChange,
        modifier = modifier.size(size),
        shape = RoundedCornerShape(corner),
    ) {
        Icon(icon, description)
    }
}

/**
 * Волнистая полоса прогресса из Material 3 Expressive.
 * Волна бежит, пока трек играет, и выравнивается на паузе. Её можно тянуть и нажимать для перемотки.
 */
@Composable
fun WavyProgressBar(
    progress: Float,
    isPlaying: Boolean,
    onProgressChange: (Float) -> Unit,
    onProgressChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val active = MaterialTheme.colorScheme.primary
    val inactive = MaterialTheme.colorScheme.secondaryContainer
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(durationMillis = 1600, easing = LinearEasing)),
        label = "wavePhase",
    )
    val amplitudeFactor by animateFloatAsState(if (isPlaying) 1f else 0f, label = "waveAmplitude")
    val onChange by rememberUpdatedState(onProgressChange)
    val onFinished by rememberUpdatedState(onProgressChangeFinished)

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    onChange((offset.x / size.width).coerceIn(0f, 1f))
                    onFinished()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset -> onChange((offset.x / size.width).coerceIn(0f, 1f)) },
                    onDragEnd = { onFinished() },
                    onDragCancel = { onFinished() },
                ) { change, _ ->
                    change.consume()
                    onChange((change.position.x / size.width).coerceIn(0f, 1f))
                }
            },
    ) {
        val strokeWidth = 6.dp.toPx()
        val amplitude = 4.dp.toPx() * amplitudeFactor
        val wavelength = 30.dp.toPx()
        val centerY = size.height / 2f
        val startX = strokeWidth / 2f
        val endX = size.width - strokeWidth / 2f
        val progressX = startX + (endX - startX) * progress.coerceIn(0f, 1f)

        drawLine(
            color = inactive,
            start = Offset(progressX, centerY),
            end = Offset(endX, centerY),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round,
        )

        val path = Path()
        val step = 3.dp.toPx()
        var x = startX
        path.moveTo(x, centerY + amplitude * sin((x / wavelength) * 2f * PI.toFloat() - phase))
        while (x < progressX) {
            x = (x + step).coerceAtMost(progressX)
            path.lineTo(x, centerY + amplitude * sin((x / wavelength) * 2f * PI.toFloat() - phase))
        }
        drawPath(
            path = path,
            color = active,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )

        val thumbWidth = 5.dp.toPx()
        val thumbHeight = 28.dp.toPx()
        drawRoundRect(
            color = active,
            topLeft = Offset(progressX - thumbWidth / 2f, centerY - thumbHeight / 2f),
            size = Size(thumbWidth, thumbHeight),
            cornerRadius = CornerRadius(thumbWidth / 2f, thumbWidth / 2f),
        )
    }
}
