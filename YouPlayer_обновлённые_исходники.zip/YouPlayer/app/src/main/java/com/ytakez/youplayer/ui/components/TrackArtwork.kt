package com.ytakez.youplayer.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.ytakez.youplayer.YouPlayerApp
import com.ytakez.youplayer.data.Track
import kotlin.math.abs

private val palettes = listOf(
    listOf(Color(0xFF7450E8), Color(0xFFB388FF)),
    listOf(Color(0xFF006874), Color(0xFF4FD8EB)),
    listOf(Color(0xFF9A4522), Color(0xFFFFB59C)),
    listOf(Color(0xFF415F91), Color(0xFFAAC7FF)),
    listOf(Color(0xFF7D5260), Color(0xFFEFB8C8)),
)

@Composable
fun TrackArtwork(
    track: Track,
    modifier: Modifier = Modifier,
    shape: Shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
    iconSize: Dp = 28.dp,
) {
    val app = LocalContext.current.applicationContext as YouPlayerApp
    val bitmapState = remember(track.id) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(track.id) {
        bitmapState.value = app.artworkCache.artwork(track)
    }
    val bitmap = bitmapState.value
    val colors = palettes[abs(track.id.hashCode()) % palettes.size]
    Box(
        modifier = modifier.clip(shape).background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center,
    ) {
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(), contentDescription = null,
                modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop,
            )
        } ?: Icon(
            Icons.Rounded.MusicNote, contentDescription = null,
            tint = Color.White.copy(alpha = 0.9f), modifier = Modifier.size(iconSize),
        )
    }
}
