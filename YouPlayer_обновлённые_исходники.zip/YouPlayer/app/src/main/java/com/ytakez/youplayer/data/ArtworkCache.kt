package com.ytakez.youplayer.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class ArtworkCache(private val context: Context) {
    private val bitmaps = LruCache<String, Bitmap>(24)
    private val mutex = Mutex()

    suspend fun artwork(track: Track): Bitmap? = withContext(Dispatchers.IO) {
        bitmaps.get(track.id)?.let { return@withContext it }
        mutex.withLock {
            bitmaps.get(track.id)?.let { return@withLock it }
            val retriever = MediaMetadataRetriever()
            val bitmap = try {
                retriever.setDataSource(context, Uri.parse(track.uri))
                retriever.embeddedPicture?.let { bytes -> BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
            } catch (_: Exception) {
                null
            } finally {
                try { retriever.release() } catch (_: Exception) { }
            }
            bitmap?.let { bitmaps.put(track.id, it) }
            bitmap
        }
    }
}
