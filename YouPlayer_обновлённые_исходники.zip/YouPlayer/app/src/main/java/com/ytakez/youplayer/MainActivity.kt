package com.ytakez.youplayer

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.ytakez.youplayer.data.PlayerSnapshot
import com.ytakez.youplayer.data.SmartMixEngine
import com.ytakez.youplayer.data.Track
import com.ytakez.youplayer.player.YouPlayerService
import com.ytakez.youplayer.ui.components.MiniPlayer
import com.ytakez.youplayer.ui.screens.HomeScreen
import com.ytakez.youplayer.ui.screens.LibraryScreen
import com.ytakez.youplayer.ui.screens.MixScreen
import com.ytakez.youplayer.ui.screens.NowPlayingScreen
import com.ytakez.youplayer.ui.theme.YouPlayerTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val snapshot = mutableStateOf(PlayerSnapshot())
    private val mixActive = mutableStateOf(false)
    private val mixSeed = mutableStateOf<Track?>(null)
    private val mixEngine = SmartMixEngine()
    private val resumeTick = mutableIntStateOf(0)

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasAudioPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED

    private fun needsNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }

    private val controllerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = updateSnapshot()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YouPlayerTheme { YouPlayerContent() }
        }
        connectController()
    }

    private fun connectController() {
        if (controllerFuture != null) return
        val token = SessionToken(this, ComponentName(this, YouPlayerService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            runCatching {
                controller = future.get().also { it.addListener(controllerListener) }
                updateSnapshot()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }

    override fun onDestroy() {
        controller?.removeListener(controllerListener)
        controllerFuture?.let(MediaController::releaseFuture)
        controller = null
        controllerFuture = null
        super.onDestroy()
    }

    private fun updateSnapshot() {
        val media = controller ?: return
        val count = media.mediaItemCount
        snapshot.value = PlayerSnapshot(
            currentTrackId = media.currentMediaItem?.mediaId,
            currentIndex = media.currentMediaItemIndex,
            queueIds = (0 until count).map { media.getMediaItemAt(it).mediaId },
            isPlaying = media.isPlaying,
            positionMs = media.currentPosition.coerceAtLeast(0L),
            durationMs = media.duration.takeIf { it > 0 && it != C.TIME_UNSET } ?: 0L,
            shuffleEnabled = media.shuffleModeEnabled,
            repeatMode = media.repeatMode,
        )
    }

    private fun playQueue(tracks: List<Track>, startIndex: Int, asMix: Boolean = false, seed: Track? = null) {
        val media = controller ?: return
        if (tracks.isEmpty()) return
        mixActive.value = asMix
        mixSeed.value = seed
        media.stop()
        media.clearMediaItems()
        media.setMediaItems(tracks.map(Track::mediaItem), startIndex.coerceIn(tracks.indices), 0L)
        media.shuffleModeEnabled = false
        media.repeatMode = if (asMix) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL
        media.prepare()
        media.play()
        updateSnapshot()
    }

    private fun startMix(tracks: List<Track>) {
        val seed = mixEngine.chooseSeed(tracks, (application as YouPlayerApp).repository.stats.value) ?: return
        val mix = mixEngine.buildMix(seed, tracks, (application as YouPlayerApp).repository.stats.value)
        playQueue(mix, 0, asMix = true, seed = seed)
    }

    private fun playPause() {
        val media = controller ?: return
        if (media.playbackState == Player.STATE_IDLE) media.prepare()
        if (media.isPlaying) media.pause() else media.play()
    }

    private fun next() {
        controller?.let { if (it.hasNextMediaItem()) it.seekToNextMediaItem() }
    }

    private fun previous() {
        controller?.let {
            if (it.currentPosition > 3_000L) it.seekTo(0L)
            else if (it.hasPreviousMediaItem()) it.seekToPreviousMediaItem()
            else it.seekTo(0L)
        }
    }

    @Composable
    private fun YouPlayerContent() {
        val app = application as YouPlayerApp
        val repository = app.repository
        val tracks by repository.tracks.collectAsStateWithLifecycle()
        val stats by repository.stats.collectAsStateWithLifecycle()
        val isScanning by repository.isScanning.collectAsStateWithLifecycle()
        val player by snapshot
        val currentTrack = repository.track(player.currentTrackId)
        val isMix by mixActive
        val seed by mixSeed
        val scope = rememberCoroutineScope()
        val snackbar = remember { SnackbarHostState() }
        var tab by rememberSaveable { mutableIntStateOf(0) }
        var showPlayer by rememberSaveable { mutableStateOf(false) }
        var showClearDialog by remember { mutableStateOf(false) }

        fun scanMessage(count: Int) = if (count > 0) "Найдено новых треков: $count" else "Музыка обновлена"
        var audioGranted by remember { mutableStateOf(hasAudioPermission()) }
        var askedOnce by rememberSaveable { mutableStateOf(false) }
        val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            audioGranted = granted
            askedOnce = true
            if (needsNotificationPermission()) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        fun requestAudioAccess() {
            if (askedOnce && !shouldShowRequestPermissionRationale(audioPermission)) openAppSettings()
            else audioLauncher.launch(audioPermission)
        }

        LaunchedEffect(Unit) {
            if (!audioGranted && !askedOnce) audioLauncher.launch(audioPermission)
            else if (needsNotificationPermission()) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        LaunchedEffect(Unit) {
            while (isActive) {
                updateSnapshot()
                delay(400)
            }
        }
        // Поиск музыки: при запуске, при возврате в приложение и после выдачи доступа.
        val tick = resumeTick.intValue
        LaunchedEffect(tick, audioGranted) {
            audioGranted = hasAudioPermission()
            if (audioGranted) repository.scanDevice()
        }

        LaunchedEffect(player.currentIndex, player.queueIds.size, isMix) {
            val media = controller
            if (isMix && media != null && seed != null && player.queueIds.isNotEmpty() &&
                player.queueIds.size - player.currentIndex <= 5
            ) {
                val queue = player.queueIds.mapNotNull(repository::track).toMutableList()
                val oldSize = queue.size
                mixEngine.extendMix(seed!!, queue, tracks, stats, count = 20)
                if (queue.size > oldSize) media.addMediaItems(queue.drop(oldSize).map(Track::mediaItem))
            }
        }

        fun openPlayer() { showPlayer = true }
        fun playTrack(track: Track) {
            val index = tracks.indexOfFirst { it.id == track.id }.coerceAtLeast(0)
            playQueue(tracks, index)
            openPlayer()
        }

        BackHandler(enabled = showPlayer || tab != 0) {
            if (showPlayer) showPlayer = false else tab = 0
        }

        if (showPlayer && currentTrack != null) {
            NowPlayingScreen(
                track = currentTrack, isPlaying = player.isPlaying,
                positionMs = player.positionMs, durationMs = player.durationMs,
                liked = stats[currentTrack.id]?.liked == true,
                shuffleEnabled = player.shuffleEnabled, repeatMode = player.repeatMode,
                onClose = { showPlayer = false }, onPlayPause = ::playPause,
                onNext = ::next, onPrevious = ::previous,
                onSeek = { fraction ->
                    val duration = player.durationMs.takeIf { it > 0 } ?: currentTrack.durationMs
                    controller?.seekTo((duration * fraction).toLong())
                },
                onToggleLike = { repository.toggleLike(currentTrack.id) },
                onToggleShuffle = { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } },
                onToggleRepeat = {
                    controller?.let {
                        it.repeatMode = when (it.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                    }
                },
            )
        } else {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    Column {
                        if (currentTrack != null) {
                            MiniPlayer(
                                track = currentTrack, isPlaying = player.isPlaying,
                                progress = if (player.durationMs > 0) player.positionMs.toFloat() / player.durationMs else 0f,
                                onOpen = ::openPlayer, onPlayPause = ::playPause, onNext = ::next,
                            )
                        }
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Rounded.Home, null) }, label = { Text("Главная") })
                            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Rounded.LibraryMusic, null) }, label = { Text("Музыка") })
                            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Rounded.AutoAwesome, null) }, label = { Text("Мой микс") })
                        }
                    }
                },
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(PaddingValues(bottom = padding.calculateBottomPadding()))) {
                    when (tab) {
                        0 -> HomeScreen(
                            tracks = tracks, recent = repository.recentTracks(), stats = stats,
                            currentTrackId = player.currentTrackId,
                            onPlayMix = { startMix(tracks); tab = 2 }, onPlayTrack = ::playTrack,
                            hasPermission = audioGranted, isScanning = isScanning,
                            onOpenLibrary = { tab = 1 },
                            onRequestPermission = ::requestAudioAccess,
                        )
                        1 -> LibraryScreen(
                            tracks = tracks, stats = stats, currentTrackId = player.currentTrackId, isScanning = isScanning,
                            hasPermission = audioGranted,
                            onPlayQueue = { queue, index -> playQueue(queue, index); openPlayer() },
                            onRequestPermission = ::requestAudioAccess,
                            onRefresh = { scope.launch { snackbar.showSnackbar(scanMessage(repository.scanDevice())) } },
                        )
                        else -> MixScreen(
                            tracks = tracks, queue = player.queueIds.mapNotNull(repository::track), seed = seed,
                            stats = stats, currentTrackId = player.currentTrackId, isMixActive = isMix,
                            onStartMix = { startMix(tracks) },
                            onPlayAt = { index -> controller?.seekToDefaultPosition(index); controller?.play() },
                            onClearHistory = { showClearDialog = true },
                        )
                    }
                }
            }
        }

        if (showClearDialog) {
            AlertDialog(
                onDismissRequest = { showClearDialog = false },
                title = { Text("Сбросить историю?") },
                text = { Text("Счётчики прослушиваний и пропусков будут удалены. Лайки и музыкальная библиотека останутся.") },
                confirmButton = {
                    TextButton(onClick = { repository.clearHistory(); showClearDialog = false }) { Text("Сбросить") }
                },
                dismissButton = { TextButton({ showClearDialog = false }) { Text("Отмена") } },
            )
        }
    }
}
