package com.ytakez.youplayer.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

class MusicRepository private constructor(private val appContext: Context) {
    private val prefs = appContext.getSharedPreferences("youplayer_library", Context.MODE_PRIVATE)
    private val lock = Any()

    private val _tracks = MutableStateFlow(loadTracks())
    val tracks: StateFlow<List<Track>> = _tracks.asStateFlow()

    private val _stats = MutableStateFlow(loadStats())
    val stats: StateFlow<Map<String, ListeningStats>> = _stats.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    fun track(id: String?): Track? = _tracks.value.firstOrNull { it.id == id }

    fun recentTracks(limit: Int = 10): List<Track> = _stats.value.entries
        .filter { it.value.lastPlayedAt > 0L }
        .sortedByDescending { it.value.lastPlayedAt }
        .mapNotNull { track(it.key) }
        .take(limit)

    /** Находит всю музыку на устройстве через MediaStore. Нужен доступ к аудио. */
    suspend fun scanDevice(): Int = withContext(Dispatchers.IO) {
        if (!_isScanning.compareAndSet(false, true)) return@withContext 0
        try {
            val found = queryDeviceAudio() ?: return@withContext 0
            replaceTracks(found)
        } finally {
            _isScanning.value = false
        }
    }

    private fun queryDeviceAudio(): List<Track>? {
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val projection = buildList {
            add(MediaStore.Audio.Media._ID)
            add(MediaStore.Audio.Media.TITLE)
            add(MediaStore.Audio.Media.ARTIST)
            add(MediaStore.Audio.Media.ALBUM)
            add(MediaStore.Audio.Media.DURATION)
            add(MediaStore.Audio.Media.DISPLAY_NAME)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) add(MediaStore.Audio.Media.GENRE)
        }.toTypedArray()
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ?"
        return try {
            val result = mutableListOf<Track>()
            appContext.contentResolver.query(collection, projection, selection, arrayOf("10000"), null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val genreCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.GENRE)
                } else -1
                while (cursor.moveToNext()) {
                    val uri = ContentUris.withAppendedId(collection, cursor.getLong(idCol))
                    val fileName = cursor.getString(nameCol).orEmpty().substringBeforeLast('.')
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() && it != UNKNOWN } ?: fileName
                    val artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != UNKNOWN }
                        ?: "Неизвестный исполнитель"
                    val album = cursor.getString(albumCol)?.takeIf { it.isNotBlank() && it != UNKNOWN }
                        ?: "Без альбома"
                    val genre = if (genreCol >= 0) cursor.getString(genreCol).orEmpty() else ""
                    result += Track(idFor(uri), uri.toString(), title, artist, album, genre, cursor.getLong(durationCol))
                }
            }
            result
        } catch (_: SecurityException) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun replaceTracks(found: List<Track>): Int = synchronized(lock) {
        val oldIds = _tracks.value.mapTo(HashSet()) { it.id }
        val sorted = found.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
        _tracks.value = sorted
        saveTracks(sorted)
        sorted.count { it.id !in oldIds }
    }

    fun toggleLike(trackId: String) {
        updateStats(trackId) { it.copy(liked = !it.liked) }
    }

    fun onPlayStarted(trackId: String) {
        updateStats(trackId) {
            it.copy(playCount = it.playCount + 1, lastPlayedAt = System.currentTimeMillis())
        }
    }

    fun onCompleted(trackId: String, listenedMs: Long) {
        updateStats(trackId) {
            it.copy(completionCount = it.completionCount + 1, listeningMs = it.listeningMs + listenedMs.coerceAtLeast(0))
        }
    }

    fun onSkipped(trackId: String, listenedMs: Long) {
        updateStats(trackId) {
            it.copy(skipCount = it.skipCount + 1, listeningMs = it.listeningMs + listenedMs.coerceAtLeast(0))
        }
    }

    fun addListeningTime(trackId: String, elapsedMs: Long) {
        if (elapsedMs <= 0) return
        updateStats(trackId) { it.copy(listeningMs = it.listeningMs + elapsedMs) }
    }

    fun clearHistory() {
        val cleared = _stats.value.mapValues { ListeningStats(liked = it.value.liked) }
        _stats.value = cleared
        saveStats(cleared)
    }

    private fun updateStats(id: String, transform: (ListeningStats) -> ListeningStats) {
        synchronized(lock) {
            val updated = _stats.value.toMutableMap()
            updated[id] = transform(updated[id] ?: ListeningStats())
            _stats.value = updated.toMap()
            saveStats(updated)
        }
    }

    private fun loadTracks(): List<Track> {
        val raw = prefs.getString(KEY_TRACKS, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(Track(
                        id = item.getString("id"), uri = item.getString("uri"), title = item.getString("title"),
                        artist = item.optString("artist", "Неизвестный исполнитель"),
                        album = item.optString("album", "Без альбома"), genre = item.optString("genre"),
                        durationMs = item.optLong("duration"),
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveTracks(tracks: List<Track>) {
        val array = JSONArray()
        tracks.forEach { track ->
            array.put(JSONObject().apply {
                put("id", track.id); put("uri", track.uri); put("title", track.title)
                put("artist", track.artist); put("album", track.album); put("genre", track.genre)
                put("duration", track.durationMs)
            })
        }
        prefs.edit().putString(KEY_TRACKS, array.toString()).apply()
    }

    private fun loadStats(): Map<String, ListeningStats> {
        val raw = prefs.getString(KEY_STATS, "{}") ?: "{}"
        return try {
            val objectRoot = JSONObject(raw)
            buildMap {
                objectRoot.keys().forEach { id ->
                    val item = objectRoot.getJSONObject(id)
                    put(id, ListeningStats(
                        playCount = item.optInt("plays"), completionCount = item.optInt("completed"),
                        skipCount = item.optInt("skips"), listeningMs = item.optLong("listeningMs"),
                        lastPlayedAt = item.optLong("lastPlayed"), liked = item.optBoolean("liked"),
                    ))
                }
            }
        } catch (_: Exception) { emptyMap() }
    }

    private fun saveStats(stats: Map<String, ListeningStats>) {
        val root = JSONObject()
        stats.forEach { (id, stat) ->
            root.put(id, JSONObject().apply {
                put("plays", stat.playCount); put("completed", stat.completionCount); put("skips", stat.skipCount)
                put("listeningMs", stat.listeningMs); put("lastPlayed", stat.lastPlayedAt); put("liked", stat.liked)
            })
        }
        prefs.edit().putString(KEY_STATS, root.toString()).apply()
    }

    companion object {
        private const val KEY_TRACKS = "tracks"
        private const val KEY_STATS = "stats"
        private const val UNKNOWN = "<unknown>"
        @Volatile private var instance: MusicRepository? = null

        fun get(context: Context): MusicRepository = instance ?: synchronized(this) {
            instance ?: MusicRepository(context.applicationContext).also { instance = it }
        }

        private fun idFor(uri: Uri): String = UUID.nameUUIDFromBytes(uri.toString().toByteArray()).toString()
    }
}
