package com.ytakez.youplayer.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ytakez.youplayer.data.ListeningStats
import com.ytakez.youplayer.data.Track
import com.ytakez.youplayer.ui.components.TrackRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    tracks: List<Track>,
    stats: Map<String, ListeningStats>,
    currentTrackId: String?,
    isScanning: Boolean,
    hasPermission: Boolean,
    onPlayQueue: (List<Track>, Int) -> Unit,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(tracks, query) {
        if (query.isBlank()) tracks else tracks.filter {
            listOf(it.title, it.artist, it.album).any { field -> field.contains(query.trim(), true) }
        }
    }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Моя музыка") },
            actions = {
                FilledTonalIconButton(onClick = onRefresh, enabled = !isScanning && hasPermission, shape = CircleShape) {
                    Icon(Icons.Rounded.Refresh, "Обновить библиотеку")
                }
                Spacer(Modifier.size(8.dp))
            },
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Песня, исполнитель или альбом") }, singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                trailingIcon = { if (query.isNotEmpty()) IconButton({ query = "" }) { Icon(Icons.Rounded.Clear, "Очистить") } },
                shape = CircleShape,
            )
            if (isScanning && tracks.isNotEmpty()) {
                Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.size(10.dp)); Text("Обновляем список песен…", style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (tracks.isNotEmpty()) {
                Text(
                    if (query.isBlank()) "${tracks.size} в коллекции" else "Найдено: ${filtered.size}",
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 26.dp, vertical = 8.dp),
                )
            }
            if (filtered.isEmpty()) {
                if (tracks.isEmpty()) EmptyLibrary(hasPermission, isScanning, onRequestPermission)
                else Text("Ничего не найдено. Попробуй другой запрос.", Modifier.padding(24.dp))
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(filtered, key = { _, track -> track.id }) { index, track ->
                        TrackRow(
                            track = track, onClick = { onPlayQueue(filtered, index) },
                            isPlaying = track.id == currentTrackId, liked = stats[track.id]?.liked == true,
                        )
                    }
                    item { Spacer(Modifier.height(140.dp)) }
                }
            }
        }
    }
}
