package com.ytakez.youplayer.data

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/** Локальный трек. URI документа сохраняется, поэтому библиотека переживает перезапуск. */
data class Track(
    val id: String,
    val uri: String,
    val title: String,
    val artist: String = "Неизвестный исполнитель",
    val album: String = "Без альбома",
    val genre: String = "",
    val durationMs: Long = 0L,
) {
    fun mediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setUri(Uri.parse(uri))
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setGenre(genre)
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .build(),
        )
        .build()
}

data class ListeningStats(
    val playCount: Int = 0,
    val completionCount: Int = 0,
    val skipCount: Int = 0,
    val listeningMs: Long = 0L,
    val lastPlayedAt: Long = 0L,
    val liked: Boolean = false,
)

data class PlayerSnapshot(
    val currentTrackId: String? = null,
    val currentIndex: Int = -1,
    val queueIds: List<String> = emptyList(),
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = 0,
)
