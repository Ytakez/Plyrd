package com.ytakez.youplayer.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ytakez.youplayer.data.ListeningStats
import com.ytakez.youplayer.data.SmartMixEngine
import com.ytakez.youplayer.data.Track
import com.ytakez.youplayer.ui.components.TrackRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MixScreen(
    tracks: List<Track>,
    queue: List<Track>,
    seed: Track?,
    stats: Map<String, ListeningStats>,
    currentTrackId: String?,
    isMixActive: Boolean,
    onStartMix: () -> Unit,
    onPlayAt: (Int) -> Unit,
    onClearHistory: () -> Unit,
) {
    val engine = androidx.compose.runtime.remember { SmartMixEngine() }
    Scaffold(topBar = { TopAppBar(title = { Text("Умный микс") }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding)) {
            item { MixHero(tracks.size, onStartMix) }
            item {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(36.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(10.dp)); Text("Как микс узнаёт тебя", style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            "Лайки и полные прослушивания усиливают рекомендации. Частые пропуски ослабляют. Исполнитель, жанр и альбом помогают найти похожий звук.",
                            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                        Text(
                            "${stats.values.sumOf { it.playCount }} запусков • ${stats.values.sumOf { it.completionCount }} полных • ${stats.values.count { it.liked }} лайков",
                            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }
            }
            if (isMixActive && queue.isNotEmpty()) {
                item {
                    SectionTitle(if (seed != null) "Сейчас в миксе • от ${seed.title}" else "Сейчас в миксе")
                    FilledTonalButton(onClick = onStartMix, Modifier.padding(horizontal = 20.dp).fillMaxWidth().height(56.dp)) {
                        Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.size(8.dp)); Text("Собрать микс заново")
                    }
                }
                itemsIndexed(queue, key = { index, track -> "${index}_${track.id}" }) { index, track ->
                    TrackRow(
                        track = track, onClick = { onPlayAt(index) }, isPlaying = track.id == currentTrackId,
                        liked = stats[track.id]?.liked == true,
                        subtitle = if (seed != null && track.id != seed.id) "${track.artist} • ${engine.recommendationReason(seed, track)}" else track.artist,
                    )
                }
            } else if (tracks.isNotEmpty()) {
                item {
                    Text(
                        "Нажми «Запустить микс» — YouPlayer выберет отправной трек и построит очередь. Чем больше слушаешь, тем точнее подбор.",
                        Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (stats.values.any { it.playCount > 0 }) {
                item {
                    OutlinedButton(onClick = onClearHistory, Modifier.padding(20.dp).fillMaxWidth().height(56.dp)) {
                        Icon(Icons.Rounded.DeleteSweep, null); Spacer(Modifier.size(8.dp)); Text("Сбросить историю прослушиваний")
                    }
                }
            }
            item { Spacer(Modifier.height(130.dp)) }
        }
    }
}
