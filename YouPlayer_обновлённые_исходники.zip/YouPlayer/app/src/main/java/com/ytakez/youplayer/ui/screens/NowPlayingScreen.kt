package com.ytakez.youplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.ytakez.youplayer.data.Track
import com.ytakez.youplayer.ui.components.ExpressivePlayButton
import com.ytakez.youplayer.ui.components.ExpressiveToggleButton
import com.ytakez.youplayer.ui.components.TrackArtwork
import com.ytakez.youplayer.ui.components.WavyProgressBar
import com.ytakez.youplayer.ui.components.formatTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    track: Track,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    liked: Boolean,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onClose: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Float) -> Unit,
    onToggleLike: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
) {
    val duration = durationMs.takeIf { it > 0 } ?: track.durationMs
    var dragging by remember { mutableStateOf(false) }
    var draggedProgress by remember { mutableFloatStateOf(0f) }
    val progress = if (dragging) draggedProgress else if (duration > 0) positionMs.toFloat() / duration else 0f
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(primary.copy(alpha = 0.16f), surface.copy(alpha = 0f))))
                .verticalScroll(rememberScrollState()),
        ) {
            TopAppBar(
                title = { Text("Сейчас играет", style = MaterialTheme.typography.labelLarge) },
                navigationIcon = {
                    FilledTonalIconButton(onClick = onClose, shape = CircleShape, modifier = Modifier.padding(start = 8.dp)) {
                        Icon(Icons.Rounded.ExpandMore, "Свернуть плеер")
                    }
                },
                actions = {
                    ExpressiveToggleButton(
                        checked = liked, onCheckedChange = { onToggleLike() },
                        icon = if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        description = "Лайк", size = 48.dp,
                    )
                    Spacer(Modifier.size(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
            )
            TrackArtwork(
                track = track,
                modifier = Modifier.padding(horizontal = 28.dp, vertical = 14.dp).fillMaxWidth().aspectRatio(1f),
                shape = RoundedCornerShape(48.dp), iconSize = 96.dp,
            )
            Column(Modifier.padding(horizontal = 28.dp, vertical = 12.dp)) {
                Text(track.title, style = MaterialTheme.typography.headlineMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(track.artist, style = MaterialTheme.typography.titleMedium, color = primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track.album, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            WavyProgressBar(
                progress = progress.coerceIn(0f, 1f),
                isPlaying = isPlaying,
                onProgressChange = { dragging = true; draggedProgress = it },
                onProgressChangeFinished = { onSeek(draggedProgress); dragging = false },
                modifier = Modifier.padding(horizontal = 22.dp),
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 30.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(if (dragging) (draggedProgress * duration).toLong() else positionMs), style = MaterialTheme.typography.labelMedium)
                Text(formatTime(duration), style = MaterialTheme.typography.labelMedium)
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
            ) {
                FilledTonalIconButton(onClick = onPrevious, modifier = Modifier.size(width = 76.dp, height = 68.dp), shape = RoundedCornerShape(26.dp)) {
                    Icon(Icons.Rounded.SkipPrevious, "Предыдущий трек", Modifier.size(34.dp))
                }
                Spacer(Modifier.size(10.dp))
                ExpressivePlayButton(isPlaying = isPlaying, onClick = onPlayPause)
                Spacer(Modifier.size(10.dp))
                FilledTonalIconButton(onClick = onNext, modifier = Modifier.size(width = 76.dp, height = 68.dp), shape = RoundedCornerShape(26.dp)) {
                    Icon(Icons.Rounded.SkipNext, "Следующий трек", Modifier.size(34.dp))
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 36.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
            ) {
                ExpressiveToggleButton(
                    checked = shuffleEnabled, onCheckedChange = { onToggleShuffle() },
                    icon = Icons.Rounded.Shuffle, description = "Случайный порядок",
                )
                Spacer(Modifier.size(14.dp))
                ExpressiveToggleButton(
                    checked = repeatMode != Player.REPEAT_MODE_OFF, onCheckedChange = { onToggleRepeat() },
                    icon = if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    description = if (repeatMode == Player.REPEAT_MODE_ONE) "Повторять один трек" else "Режим повтора",
                )
            }
            Spacer(Modifier.height(36.dp))
        }
    }
}
