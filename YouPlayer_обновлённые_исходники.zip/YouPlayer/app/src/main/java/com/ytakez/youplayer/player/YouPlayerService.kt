package com.ytakez.youplayer.player

import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.ytakez.youplayer.data.MusicRepository

/** Media3 оставляет музыку играть в фоне и создаёт стандартное системное уведомление. */
class YouPlayerService : MediaSessionService() {
    private lateinit var mediaSession: MediaSession
    private lateinit var player: ExoPlayer
    private lateinit var repository: MusicRepository

    override fun onCreate() {
        super.onCreate()
        repository = MusicRepository.get(this)
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        mediaSession = MediaSession.Builder(this, player).build()
        player.addListener(TrackingListener())
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession = mediaSession

    override fun onDestroy() {
        finishTracking(completed = false, countAsSkip = false)
        player.release()
        mediaSession.release()
        super.onDestroy()
    }

    private var trackedId: String? = null
    private var listenedMs = 0L
    private var playingSince = 0L

    private inner class TrackingListener : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            finishTracking(
                completed = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO,
                countAsSkip = reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED,
            )
            trackedId = mediaItem?.mediaId
            listenedMs = 0L
            playingSince = if (player.isPlaying) System.currentTimeMillis() else 0L
            trackedId?.let(repository::onPlayStarted)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            val now = System.currentTimeMillis()
            if (isPlaying) {
                playingSince = now
            } else if (playingSince > 0L) {
                listenedMs += now - playingSince
                playingSince = 0L
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_ENDED) {
                finishTracking(completed = true, countAsSkip = false)
            }
        }
    }

    private fun finishTracking(completed: Boolean, countAsSkip: Boolean) {
        val id = trackedId ?: return
        val now = System.currentTimeMillis()
        if (playingSince > 0L) listenedMs += now - playingSince
        playingSince = 0L
        when {
            completed -> repository.onCompleted(id, listenedMs)
            countAsSkip && listenedMs >= 5_000L -> repository.onSkipped(id, listenedMs)
            else -> repository.addListeningTime(id, listenedMs)
        }
        trackedId = null
        listenedMs = 0L
    }
}
