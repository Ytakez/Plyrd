package com.ytakez.youplayer

import android.app.Application
import com.ytakez.youplayer.data.ArtworkCache
import com.ytakez.youplayer.data.MusicRepository

class YouPlayerApp : Application() {
    val repository: MusicRepository by lazy { MusicRepository.get(this) }
    val artworkCache: ArtworkCache by lazy { ArtworkCache(this) }
}
