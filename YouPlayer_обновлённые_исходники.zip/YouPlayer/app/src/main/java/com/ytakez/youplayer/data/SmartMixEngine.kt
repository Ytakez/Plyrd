package com.ytakez.youplayer.data

import kotlin.math.ln
import kotlin.math.min
import kotlin.random.Random

/**
 * Локальный рекомендательный алгоритм без сети и передачи истории прослушиваний.
 * Метаданные определяют похожесть, а поведение слушателя — персональный рейтинг.
 */
class SmartMixEngine(private val random: Random = Random.Default) {

    fun chooseSeed(tracks: List<Track>, stats: Map<String, ListeningStats>): Track? {
        if (tracks.isEmpty()) return null
        return tracks.maxByOrNull { track ->
            val s = stats[track.id] ?: ListeningStats()
            (if (s.liked) 12.0 else 0.0) + s.completionCount * 3.0 +
                min(s.playCount, 8) * 0.7 - min(s.skipCount, 8) * 1.2 +
                random.nextDouble(0.0, 2.5)
        }
    }

    fun buildMix(
        seed: Track,
        tracks: List<Track>,
        stats: Map<String, ListeningStats>,
        limit: Int = 40,
    ): List<Track> {
        if (tracks.isEmpty() || limit <= 0) return emptyList()
        val result = mutableListOf(seed)
        extendMix(seed, result, tracks, stats, (limit - 1).coerceAtLeast(0))
        return result
    }

    /** Достраивает очередь, когда слушатель приближается к её концу. */
    fun extendMix(
        seed: Track,
        currentQueue: MutableList<Track>,
        tracks: List<Track>,
        stats: Map<String, ListeningStats>,
        count: Int = 20,
    ) {
        val selected = currentQueue.mapTo(mutableSetOf()) { it.id }
        repeat(count.coerceAtMost(tracks.size * 2)) {
            val available = tracks.filter { it.id !in selected }
            if (available.isEmpty()) return
            val previous = currentQueue.lastOrNull() ?: seed
            val next = available.maxByOrNull { candidate ->
                score(candidate, seed, previous, stats[candidate.id] ?: ListeningStats())
            } ?: return
            currentQueue.add(next)
            selected.add(next.id)
        }
    }

    fun recommendationReason(seed: Track, candidate: Track): String = when {
        same(seed.artist, candidate.artist) -> "Тот же исполнитель"
        seed.genre.isNotBlank() && same(seed.genre, candidate.genre) -> "Похожий жанр"
        same(seed.album, candidate.album) -> "Из того же альбома"
        else -> "По твоим прослушиваниям"
    }

    private fun score(
        candidate: Track,
        seed: Track,
        previous: Track,
        stats: ListeningStats,
    ): Double {
        var value = 0.0
        if (same(candidate.artist, seed.artist)) value += 5.0
        if (same(candidate.album, seed.album)) value += 1.5
        if (seed.genre.isNotBlank() && same(candidate.genre, seed.genre)) value += 3.5
        if (same(candidate.artist, previous.artist)) value += 1.2
        if (previous.genre.isNotBlank() && same(candidate.genre, previous.genre)) value += 1.0

        if (stats.liked) value += 4.5
        value += min(2.0, ln((stats.playCount + 1).toDouble()) * 0.8)
        value += min(2.5, stats.completionCount * 0.45)
        value -= min(5.0, stats.skipCount * 0.75)
        if (System.currentTimeMillis() - stats.lastPlayedAt in 0..30 * 60 * 1000L) value -= 1.8

        // Небольшой шум не даёт миксу каждый раз повторять один и тот же порядок.
        return value + random.nextDouble(0.0, 1.6)
    }

    private fun same(first: String, second: String): Boolean =
        first.isNotBlank() && second.isNotBlank() && first.trim().equals(second.trim(), true)
}
