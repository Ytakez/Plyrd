package com.ytakez.youplayer.data

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartMixEngineTest {
    private val tracks = listOf(
        Track("1", "content://1", "Seed", "Artist A", "Album A", "Electronic"),
        Track("2", "content://2", "Similar", "Artist A", "Album A", "Electronic"),
        Track("3", "content://3", "Other", "Artist B", "Album B", "Rock"),
        Track("4", "content://4", "Liked", "Artist C", "Album C", "Electronic"),
    )

    @Test
    fun mixStartsWithSeedAndHasNoDuplicates() {
        val engine = SmartMixEngine(Random(7))
        val mix = engine.buildMix(tracks.first(), tracks, emptyMap(), 4)
        assertEquals("1", mix.first().id)
        assertEquals(4, mix.size)
        assertEquals(4, mix.map { it.id }.distinct().size)
    }

    @Test
    fun likedTrackIsPreferredOverUnrelatedTrack() {
        val engine = SmartMixEngine(Random(1))
        val stats = mapOf("4" to ListeningStats(liked = true))
        val mix = engine.buildMix(tracks.first(), tracks, stats, 3)
        assertTrue(mix.drop(1).any { it.id == "4" })
    }

    @Test
    fun emptyLibraryProducesEmptyMix() {
        val mix = SmartMixEngine(Random(2)).buildMix(tracks.first(), emptyList(), emptyMap())
        assertTrue(mix.isEmpty())
    }
}
